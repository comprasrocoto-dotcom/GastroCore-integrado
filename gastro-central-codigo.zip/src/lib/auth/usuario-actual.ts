import "server-only";
import { createClient } from "@/lib/supabase/server";

export type Rol = "Admin" | "Chef" | "Lector";

export type UsuarioActual = {
  id: string;
  email: string;
  nombre: string;
  rol: Rol;
  marca_id: string | null;
  sede_id: string | null;
  activo: boolean;
};

/**
 * Devuelve el usuario logueado (fila de public.usuarios) o null si no hay
 * sesión. Se apoya en RLS: la política `usuarios_lectura` permite que cada
 * quien lea su propia fila (id = private.usuario_actual()), y esa función
 * lee el claim "usuario_id" que el hook de Custom Access Token agrega al
 * JWT en cada login (ver migración 0025_custom_access_token_hook).
 *
 * Si esto devuelve null estando logueado, lo más probable es que el hook
 * de Custom Access Token todavía no esté activado en el panel de Supabase
 * (Authentication -> Hooks) — sin él, el JWT no lleva rol/marca_id/sede_id
 * y ninguna política de sede/marca puede evaluarse.
 */
export async function getUsuarioActual(): Promise<UsuarioActual | null> {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data: usuario, error } = await supabase
    .from("usuarios")
    .select("id, email, nombre, rol, marca_id, sede_id, activo")
    .eq("id", user.id)
    .single();

  if (error || !usuario) return null;

  return usuario as UsuarioActual;
}

export function esMaestro(usuario: Pick<UsuarioActual, "marca_id" | "rol">) {
  return usuario.rol === "Admin" && usuario.marca_id === null;
}

export function esAdminDeMarca(
  usuario: Pick<UsuarioActual, "marca_id" | "sede_id" | "rol">
) {
  return (
    usuario.rol === "Admin" &&
    usuario.marca_id !== null &&
    usuario.sede_id === null
  );
}
