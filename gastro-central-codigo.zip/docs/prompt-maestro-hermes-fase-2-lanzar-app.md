# Prompt maestro para Hermes — Fase 2: construir y lanzar la aplicación de Gastro Central

_Este es el texto para copiar y pegarle a Hermes tal cual. Todo lo que sigue, desde "INSTRUCCIÓN RAÍZ" hasta el final, es el prompt. Es la continuación del prompt original que ya se usó para diseñar el esquema — esta vez el trabajo es escribir la aplicación de verdad y dejarla publicada._

---

## INSTRUCCIÓN RAÍZ

La base de datos de Gastro Central **ya existe y ya tiene datos reales cargados**. No la rediseñes, no la recrees, no borres nada de ella salvo que se indique explícitamente abajo. Tu trabajo en esta fase es: (1) escribir la aplicación web (Next.js) que se conecta a esa base, (2) implementar login con roles y aislamiento por marca/sede, (3) construir los módulos funcionales, más simples y comprensibles que el GastroCore actual, y (4) dejar la aplicación publicada y funcionando en Vercel.

No toques ni conectes nada del proyecto GastroCore actual (repositorio `comprasrocoto-dotcom/GastroCore`, base de Supabase `pnotebuwhcuqapynjgrk`, ni sus hojas de Google Sheets). Sigue funcionando en producción y no debe arriesgarse bajo ninguna circunstancia.

## 1. Estado actual — qué ya está construido (verificado en vivo, no lo repitas)

**Supabase — proyecto `gastrocore-integrado`:**
- Project ID: `slbehczdonbzpneyglrx`
- URL: `https://slbehczdonbzpneyglrx.supabase.co`
- Publishable/anon key (segura para el cliente, ya es pública por diseño):
  `sb_publishable_ixlloN_2eR1kNrwGaEUSlA_Tcqh3N0_`
  (o la variante legacy `anon` JWT, ambas activas — usa la que prefiera tu stack)
- La `service_role key` **no está en este prompt a propósito** — pídesela a Mariluz directamente si la necesitas para alguna tarea de servidor, nunca la generes ni la asumas.

**Esquema ya creado (16 tablas), con RLS activo en todas y sin alertas de seguridad pendientes** (verificado con el advisor de seguridad de Supabase, 0 avisos):
`marcas`, `sedes`, `usuarios`, `unidades_medida`, `familias`, `subfamilias`, `insumos`, `precios_historicos`, `subrecetas`, `recetas`, `ingredientes_receta`, `fichas_tecnicas`, `historial_recetas`, `configuracion`. (Las tablas `centros_produccion` y `centros_produccion_marcas` se eliminaron por decisión de negocio — no hace falta ese módulo, ver sección 3.)

**Datos ya cargados:**

| Marca | Sedes | Insumos cargados |
|---|---|---|
| 123 WOK | Oviedo, Interplaza, Laureles, Tesoro | 470 / 423 / 451 / 169 |
| Malanga | Malanga | 670 |
| Sinpar | Sinpar | 562 |
| Rocoto | Rocoto | 506 |
| Casa de Nadie | Casa de Nadie | 633 |

Total: 5 marcas, 8 sedes, 19 familias, 132 subfamilias, **3,884 insumos**. Las recetas, subrecetas y fichas técnicas están vacías todavía — se van a ir creando desde la aplicación a medida que Mariluz las capture, tal como pidió ella explícitamente ("la idea es que las recetas se vayan guardando a medida que las cree en Gastrocore").

**GitHub:** repositorio `https://github.com/comprasrocoto-dotcom/GastroCore-integrado`, hoy vacío salvo un `README.md`. Ahí va el código de la aplicación.

**Nota técnica de una limitación del entorno anterior (no tuya, pero verifícala):** la sesión que construyó el esquema no tenía permiso para hacer `git push` a este repositorio (bloqueo del proxy de git de su entorno, no del repositorio en sí). Antes de empezar a programar, confirma tú mismo que puedes leer y escribir en el repo — si no puedes, dile a Mariluz antes de avanzar, no trabajes en un lugar que después no se pueda subir.

## 2. Reglas de negocio que se conservan tal cual (no reinventar, no “mejorar”)

**Fórmulas de costeo — copiar exactamente:**

```ts
export const INC = 0.08;          // Impuesto al Consumo (fijo)
export const FC_OBJ = 0.35;       // Food Cost objetivo (fijo)
export const FC_OBJ_PANEL = 0.30; // FC objetivo solo para la sugerencia del Panel Ejecutivo

precioBaseSinImpuesto(precioReal) = precioReal / (1 + INC)
foodCost(costoPorcion, precioReal) = costoPorcion / precioBaseSinImpuesto(precioReal)
precioSugerido(costoPorcion) = (costoPorcion / FC_OBJ) * (1 + INC)
precioSugeridoPanel(costoPorcion) = (costoPorcion / FC_OBJ_PANEL) * (1 + INC)
utilidad(precioReal, costoPorcion) = precioReal - costoPorcion
margenBruto(precioReal, costoPorcion) = (precioReal - costoPorcion) / precioReal

Semáforo de Food Cost: verde <= 33%, amarillo 33–35%, rojo > 35%.
```

**Importante — cambio deliberado frente al GastroCore actual:** la tabla `recetas` de Gastro Central **no guarda** `food_cost`, `precio_sugerido` ni `margen_objetivo` como columnas. Se calculan al vuelo con las fórmulas de arriba cada vez que se muestran, usando `costo_porcion` + `precio_real` + `iva` guardados. Esto es intencional — así nunca quedan desactualizados si cambia el costo de un insumo. Pon esta lógica en un único módulo de costeo, no la dupliques en varias pantallas.

**Merma y desvío:** la merma **divide** (cantidad real = cantidad ÷ (1 − merma%)); el desvío **multiplica** el costo de ingredientes.

**Patrón maestro-calculadora de subrecetas:** toda preparación intermedia vive como un insumo normal (artículo con prefijo `SUB.`) para poder usarse dentro de otras recetas. Ese insumo tiene una "subreceta" asociada (tabla `subrecetas`, columna `insumo_id`) que es su calculadora: ingredientes + rendimiento → `costo_unitario`. Cuando se actualiza una subreceta, su costo debe empujarse al insumo maestro (`insumos.coste`), dejar registro en `precios_historicos`, y disparar el recálculo de toda receta que use ese insumo. Es la pieza más delicada del sistema — pruébala con un caso real antes de darla por terminada.

## 3. Decisiones de negocio ya tomadas (no las vuelvas a preguntar)

- **Marca ↔ sede:** una sede pertenece a una sola marca. 123 WOK tiene 4 sedes (Oviedo, Interplaza, Laureles, Tesoro); las demás marcas (Malanga, Sinpar, Rocoto, Casa de Nadie) tienen una sola sede cada una, con el mismo nombre que la marca.
- **Roles:** se asignan por usuario. `marca_id` NULL en `usuarios` = Admin multi-marca ("maestro", o sea Mariluz) — ve todo. `marca_id` fijo + `sede_id` NULL = Admin de toda esa marca (todas sus sedes). `marca_id` + `sede_id` fijos = usuario de una sola sede.
- **No hay módulo de "Centros de Producción".** Se evaluó y se descartó — Gastro Central solo maneja las 5 marcas reales de la tabla de la sección 1.
- **Simplicidad ante todo:** Mariluz pidió explícitamente que Gastro Central tenga los mismos módulos funcionales que el GastroCore actual, pero **más comprensibles** — menos pasos, menos jerga técnica visible, flujos más directos. Prioriza claridad sobre replicar la interfaz actual.

## 4. Qué construir en esta fase, en orden — probar cada una antes de pasar a la siguiente

1. **Scaffold de la aplicación** en el repositorio `GastroCore-integrado`: Next.js App Router (o el stack que recomiendes, justificándolo brevemente), cliente de Supabase configurado con las credenciales de la sección 1, `.env.example` documentado (nunca comitear `.env` real ni ninguna clave).
2. **Autenticación:** usar Supabase Auth. El JWT debe llevar (o resolverse a partir de la fila en `usuarios`) los claims `rol`, `marca_id`, `sede_id`, `usuario_id` que ya esperan las políticas de RLS existentes — revisa las políticas actuales antes de tocarlas, no las tienes que reescribir, solo respetarlas.
3. **Selector de marca/sede** en la UI: el "maestro" (Mariluz) debe poder cambiar de marca y de sede libremente y ver cuál es cuál; un Admin de marca ve un selector solo de sus sedes; un usuario de una sola sede no ve selector.
4. **Módulo de insumos:** listar/editar los 3,884 ya cargados por sede, con historial de precios (`precios_historicos`).
5. **Módulo de familias/subfamilias:** ya están cargadas, solo falta la UI para administrarlas.
6. **Módulo de recetas + subrecetas:** con el patrón maestro-calculadora de la sección 2, calculando food cost/precio sugerido/semáforo al vuelo.
7. **Fichas técnicas e historial:** con snapshot por versión (`historial_recetas.snapshot`, jsonb).
8. **Recetario público:** vista de solo lectura para cocina, sin costos, precios ni márgenes — ni siquiera indirectamente. Cualquier vista SQL nueva que crees para esto debe llevar `security_invoker = true` (ver sección 5, es la causa real de un hallazgo de seguridad grave en el proyecto anterior — no lo repitas).
9. **Deploy a Vercel:** proyecto nuevo conectado al repo `GastroCore-integrado`, variables de entorno cargadas en el panel de Vercel (nunca en el código), dominio de prueba de Vercel para empezar (ver pregunta abierta en sección 6 sobre el dominio final).

## 5. Reglas no negociables de seguridad

- **No desactives ni debilites ninguna política de RLS existente.** Si necesitas una política nueva para una tabla o vista que tú agregues, actívala en el mismo commit en que creas esa tabla/vista.
- **Toda vista SQL que crees debe llevar `security_invoker = true`.** En el proyecto GastroCore original, dos vistas heredadas corrían con los permisos de su dueño en vez de los del usuario que consulta, dejando accesible con la llave pública la lectura y edición de costos de todas las marcas. Ya se corrigió ahí, pero es el error más caro que ha tenido este sistema — no lo repitas aquí.
- **La `service_role key` nunca se usa en el cliente/navegador**, solo en funciones de servidor, y aun ahí no reemplaza RLS.
- **Nunca comitees `.env` ni ninguna clave, en ningún commit, ni siquiera temporalmente.**
- **Cada módulo se prueba con datos reales antes de seguir al siguiente** — que compile no significa que funcione.
- **Ninguna decisión de negocio se asume.** Si algo no está cubierto por las secciones 2 y 3, pregúntale a Mariluz antes de fijarlo en código — no lo inventes.

## 6. Preguntas abiertas — pregúntaselas a Mariluz antes de la etapa que dependa de cada una

- **Dominio final:** ¿Gastro Central debe terminar en el mismo dominio que usa GastroCore hoy (una vez que esté listo para reemplazarlo), o en un dominio/subdominio totalmente aparte mientras se prueba?
- **Alta de usuarios:** ¿Mariluz va a crear los usuarios (Admin/Chef/Lector de cada sede) ella misma desde un panel, o hace falta un flujo de invitación por correo?
- **Migración de recetas existentes:** ¿hay recetas/subrecetas/fichas técnicas ya armadas en el GastroCore actual que se deban traer como punto de partida, o Gastro Central arranca con el recetario vacío y se captura todo de nuevo desde la app (como ella describió inicialmente)?

## 7. Al terminar

Antes de avisar que "ya está lanzada", verifica en orden: (1) login funciona con al menos un usuario de cada tipo de rol, (2) una sede no puede ver ni editar datos de otra sede probándolo con dos usuarios reales, (3) el cálculo de food cost de al menos 3 recetas de prueba coincide con el cálculo manual usando las fórmulas de la sección 2, (4) el deploy de Vercel está en verde y accesible desde el link público, (5) ninguna clave quedó comiteada en el repositorio. Reporta a Mariluz en español simple, con el link de la aplicación ya publicada y el link del repositorio.
